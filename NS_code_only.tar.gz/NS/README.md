# FaNO on Navier-Stokes

This folder contains the minimal runnable code for FaNO on the two-dimensional incompressible Navier-Stokes benchmark.

## Files

- train_ns.py: training script copied from the working FaNO NS implementation.
- test_ns.py: evaluation and zero-shot rollout script copied from the working FaNO NS implementation.
- utilities3.py: utility functions for reading .mat files and computing losses.
- requirements.txt: minimal dependencies.

## Data

The default example assumes the Navier-Stokes data file is located at:

../data/NavierStokes_V1e-5_N1200_T20.mat

## Example evaluation

python test_ns.py --ckpt ../finaltrain/model/gfno_official_aligned_base_ns_V1e-5_N1000_ep500_m8x8_w20_pr0p1_official_eval_base_samew20_pr0p10_best.pt --test_path ../data/NavierStokes_V1e-5_N1200_T20.mat --variant base --persistent_ratio 0.10 --modes1 8 --modes2 8 --width 20 --ntest 200 --batch_size 20 --sub 1 --S 64 --T_in 10 --T 10 --step 1 --tag fano_ns64_v1e5 --save_npz rollout_npz/fano_ns64_v1e5.npz

## Expected result

params: 190421
ZEROSHOT_RESULT tag=fano_ns64_v1e5 S=64 step=0.16141005 full=0.18895787
